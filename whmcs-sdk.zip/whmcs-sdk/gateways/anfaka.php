<?php
//安发卡支付接口文件

include_once __DIR__ . '/anfaka/sdk.php';

function anfaka_config()
{
    $configarray = array(
        "FriendlyName" => array("Type" => "System", "Value" => "安发卡收银台"),
        "uid" => array("FriendlyName" => "商户ID", "Type" => "text", "Size" => "10",),
        "key" => array("FriendlyName" => "商户密钥", "Type" => "text", "Size" => "32",),
        "payways" => array("FriendlyName" => "支付方式", "Type" => "text", "Size" => "255", "Value" => "alipay|wechat|qq",),
    );
    return $configarray;
}

function anfaka_link($params)
{

    $_input_charset = "utf-8";   //字符编码格式 目前支持 GBK 或 utf-8
    $sign_type = "MD5";     //加密方式 系统默认(不要修改)
    $transport = $params['transport'];   //访问模式,你可以根据自己的服务器是否支持ssl访问而选择http以及https访问模式(系统默认,不要修改)

    # Gateway Specific Variables
    $gatewaySELLER_ID = $params['seller_id'];
    $gatewaySELLER_UID = $params['uid'];
    $gatewaySELLER_KEY = $params['key'];

    $gatewayPAYWAYS = explode('|', $params['payways']);

    # Invoice Variables
    $invoiceid = $params['invoiceid'];
    $description = $params["description"];
    $amount = $params['amount']; # Format: ##.##

    # System Variables
    $companyname = $params['companyname'];
    $systemurl = $params['systemurl'];
    $return_url = $systemurl . "modules/gateways/anfaka/return.php";
    $notify_url = $systemurl . "modules/gateways/anfaka/notify.php";

    $api = new anfaka('https://www.327ka.com', $gatewaySELLER_UID, $gatewaySELLER_KEY);
    if (isset($_GET['way'])) {
        $payway = $_GET['way'];
        if (in_array($payway, ['alipay', 'alipaywap', 'wx', 'wxwap', 'qq', 'qqwap'])) {
            $total_fee = (int)round($amount * 100);
            $no = $invoiceid . '|' . $params['currency'] . '|' . $total_fee . '|' . $payway; // 防止更新订单, 用一系列要素来生成订单号
            $api->goPay($payway, "$companyname 账单 #$invoiceid", $no, 0, $total_fee, '', $return_url, $notify_url);
        } else {
            // 非法操作;
            die('404');
        }
    }

    $is_mobile = is_mobile();
    $code = '
<style type="text/css">
.payway {
    position: relative;
    display: inline-block;
    margin: 4px 12px 4px 0;
    padding: 4px;
    cursor: pointer;
    border: 1px solid transparent
}

.payway img {
    height: 48px
}

.payway p {
    text-align: center;
    margin: 0
}
</style>
<div class="anfaka-payway">
';
    foreach ($gatewayPAYWAYS as $payway_i) {
        if (strtolower($payway_i) === 'alipay') {
            if ($is_mobile)
                $code .= '<a class="payway" href="' . $params['returnurl'] . '&way=alipaywap' . '"><img src="' . $systemurl . 'modules/gateways/anfaka/ali.png" alt="使用支付宝结账"><p>支付宝</p></a>';
            else
                $code .= '<a class="payway" href="' . $params['returnurl'] . '&way=alipay' . '"><img src="' . $systemurl . 'modules/gateways/anfaka/ali.png" alt="使用支付宝结账"><p>支付宝</p></a>';
        } elseif (strtolower($payway_i) === 'wechat') {
            if ($is_mobile)
                $code .= '<a class="payway" href="' . $params['returnurl'] . '&way=wxwap' . '"><img src="' . $systemurl . 'modules/gateways/anfaka/wx.png" alt="使用微信结账"><p>微信</p></a>';
            else
                $code .= '<a class="payway" href="' . $params['returnurl'] . '&way=wx' . '"><img src="' . $systemurl . 'modules/gateways/anfaka/wx.png" alt="使用微信扫码结账"><p>微信扫码</p></a>';
        } elseif (strtolower($payway_i) === 'qq') {
            if ($is_mobile)
                $code .= '<a class="payway" href="' . $params['returnurl'] . '&way=qqwap' . '"><img src="' . $systemurl . 'modules/gateways/anfaka/qq.png" alt="使用手机QQ结账"><p>手机QQ</p></a>';
            else
                $code .= '<a class="payway" href="' . $params['returnurl'] . '&way=qq' . '"><img src="' . $systemurl . 'modules/gateways/anfaka/qq.png" alt="使用手机QQ扫码结账"><p>手机QQ扫码</p></a>';
        }
    }
    $code .= '</div>';

    if (stristr($_SERVER['PHP_SELF'], 'viewinvoice')) {
        return $code;
    } else {
        return '<img style="width: 150px" src="' . $systemurl . 'modules/gateways/anfaka/logo.png" alt="安发卡收银台" />';
    }
}

function is_mobile()
{
    //判断手机发送的客户端标志
    if (isset ($_SERVER['HTTP_USER_AGENT'])) {
        // 从HTTP_USER_AGENT中查找手机浏览器的关键字
        if (preg_match('/(iPhone|iPod|Android|ios|SymbianOS|Windows Phone)/i', $_SERVER['HTTP_USER_AGENT'])) {
            return true;
        }
    }
    return false;
}

?>