<?php
# 同步返回页面
# Required File Includes
include("../../../init.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");
include("./sdk.php");


$gatewaymodule = 'anfaka';
$GATEWAY = getGatewayVariables($gatewaymodule);

$url = $GATEWAY['systemurl'];
$companyname = $GATEWAY['companyname'];
$currency = $GATEWAY['currency'];

if (!$GATEWAY["type"]) die("Module Not Activated");

$gatewaySELLER_UID = $GATEWAY['uid'];
$gatewaySELLER_KEY = $GATEWAY['key'];
$api = new anfaka('https://www.327ka.com', $gatewaySELLER_UID, $gatewaySELLER_KEY);

if ($api->notify_verify()) {//验证成功
    # Get Returned Variables
    $invoiceid = explode('|', $_POST['out_trade_no'])[0]; //获取传递过来的订单号
    $transid = $_POST['order_no'];       //获取传递过来的交易号
    $amount = sprintf('%.2f', $_POST['total_fee'] / 100);       //获取传递过来的总价格
    $fee = 0;

    $paidcurrency = "CNY";
    $result = select_query('tblcurrencies', '', array('code' => $paidcurrency));
    $data = mysql_fetch_array($result);
    $paidcurrencyid = $data['id'];

    $invoiceid = checkCbInvoiceID($invoiceid, $GATEWAY["name"]);
    $result = select_query('tblinvoices', '', array('id' => $invoiceid));
    $data = mysql_fetch_array($result);
    $userid = $data['userid'];
    $currency = getCurrency($userid);
    $amount = convertCurrency($amount, $paidcurrencyid, $currency['id']);
    checkCbTransID($transid);
    addInvoicePayment($invoiceid, $transid, $amount, $fee, $gatewaymodule);
    logTransaction($GATEWAY["name"], $_POST, "Successful-A");

} else {
    logTransaction($GATEWAY["name"], $_POST, "Unsuccessful");
}
?>